# adobe-jupiter-wp-plugin
Plugin for the new version of DPS



# If you need to change the refresh token
https://aex.stage02.digitalpublishing.adobe.com/index.html#/

#TODO Before Launch
License File
Rename all package to official name


CMS Class

pubic init()
public get_cms_version()
public get_settings()
public save_settings()

Todo:

Article Name (Add option to change order and fields)
Article and what collections it's associated with
What collections that content belongs to
> Search properties - choose
> Search results: Article Name : Title : Found field

Add to collection window 
> Create collection in that window


Tools:
Import sidecar

/* ADD TO CMS or TEMPLATE */

// update image references to be local for folio
foreach ($images as $image) {
    $attachmentID = $this->get_attachment_from_imageURL($image->src, $article["localID"]);
    if($attachmentID){
        // try to get attachment image
        $imagePath = get_attached_file($attachmentID);
        // use WP's new                     
        $img = wp_get_image_editor( $imagePath );
        if ( ! is_wp_error( $img ) ) {
            //$old_size = $img->get_size(); // $old_size['width'], $old_size['height']
            $resize = $img->resize( 1280, false );
            $extension = pathinfo($imagePath, PATHINFO_EXTENSION);
            //$img->set_quality( 100 );
            if ($resize !== FALSE) {
                $new_size = $img->get_size();
                $image->width = $new_size['width'];
                $image->height = $new_size['height'];
            }
            $file = tempnam(DPSFA_TMPDIR, 'dps-' . basename($image->src) . $extension );
            
            $imageDetails = wp_check_filetype($imagePath);
            $return = $img->save($file,$imageDetails["type"]);
            $asset = array("path" => $return["path"], "filename" => basename($img->generate_filename()) );
        }
    }else{
        // if it can't find the attachment ID then use default image
        $filePath = $this->get_image( DPSFA_URL . "/assets/classic/folio/notlinked.gif" );
        $asset = array("path" => $filePath, "filename" => "notlinked.gif");
    }
    
    if( !empty($asset) ){
        $zipPath = "assets/images/" . $asset["filename"];
        $image->src = $zipPath;
        $assets[$zipPath] = $asset["path"];
    }
}

private function get_attachment_from_imageURL( $URL, $articleID ){
            $attachment = $this->search_wp_for_attachment($URL);
            if( count($attachment) > 0){
            	return $attachment[0];
            }else{
	            // No image found - it could be that it was linking to a rendtion or it's on a different server
                $ext = pathinfo($URL, PATHINFO_EXTENSION);
                $imageURL = preg_replace('/-(\d{1,})x(\d{1,}).'.$ext.'/', '', $URL);
                
                $newext = pathinfo($imageURL, PATHINFO_EXTENSION);
                if( empty($newext) ){
                	$imageURL .= "." . $ext;
                }
				$attachment = $this->search_wp_for_attachment($imageURL);
                
                // last check, if it still can't find a local attachement, it might be on another server
                if( count($attachment) > 0 ){
	                return $attachment[0];
                }else{
                	// try downloading the image manually from the linked server
                	$tmp = download_url( $URL );
                	preg_match('/[^\?]+\.(jpg|JPG|jpe|JPE|jpeg|JPEG|gif|GIF|png|PNG)/', $URL, $matches);
                	$file_array['name'] = basename($matches[0]);
                	$file_array['tmp_name'] = $tmp;
                	if ( !is_wp_error( $tmp ) ) {
                		$attachmentID = media_handle_sideload( $file_array, $articleID );
                        if(!is_wp_error($attachmentID)){
                        	return $attachmentID;
                        }
                	}
                }
            }
            return false;
        }
        
        private function search_wp_for_attachment( $URL ){
	        global $wpdb;
            $prefix = $wpdb->prefix;
            return $wpdb->get_col($wpdb->prepare("SELECT ID FROM " . $prefix . "posts" . " WHERE guid='%s';", $URL )); 
        }