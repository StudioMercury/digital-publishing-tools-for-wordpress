<?php
/*
Template Name: Adobe Publish - Individual Recipe
*/
?>
<?php 

    // Make sure a recipe ID is set - then query that post
    if( isset($_GET["recipe"]) ) { 
        $recipeID = htmlspecialchars($_GET["recipe"]); 
        query_posts( array ( 'p' => $recipeID, 'post_type' => 'recipes' ) );
    }

    // Is this for a Folio or for preview
    if( isset($_GET["bundle"]) ) {
        $filePath = '../HTMLResources/';
        $urlPath = 'navto://';
    } else {
        $filePath = get_bloginfo('template_directory') . '/dps-templates/HTMLResources/';
        $urlPath = site_url() . '/templates/individual-recipe/?recipe=';
    }

?>

<?php if ( have_posts() ) : while (have_posts()) : the_post(); ?>
    
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" ng-app> <!--<![endif]-->
<head>        
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="description" content="<?php the_excerpt(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    
    <title>Gather Journal - <?php the_title(); ?></title>        
    
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/fonts.css">        
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/gather-journal-font.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/theme.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/template-recipe.css">

</head>


<body id="single-recipe" ng-app="">

    <header class="header white">
        
    	<div class="navigation">
    	 <div class="container">
    	 
    		<div class="row">
    		    <a class="navbar-link col-xs-6 col-sm-4 text-left" href="goto://ApplicationViewState/library"><i class="gj-icon-recipes"></i></a>
                <!-- <a class="navbar-link col-xs-2 col-sm-1 text-left" href="goto://ApplicationViewState/library"><i class="fa fa-angle-left"></i></a> -->
    		    
    			<a class="navbar-link col-xs-2 col-sm-1"></a>
    			    
    			<!-- <a class="navbar-link col-xs-2 col-sm-1 text-center" ng-click="addRecipe(recipe.objectId);"><i class="gj-icon-star"></i></a> -->
                <!-- <a class="navbar-link col-xs-2 col-sm-1 text-center" href="goto://ApplicationViewState/recipe-box"><i class="gj-icon-recipe-box"></i></a> -->
    		</div>
    
    	 </div>
    	</div>
    
    	<div id="recipe-nav-xs" class="visible-xs">
            <ul class="sans-serif">
                <li class="letter-spacing"><a href="#ingredients" onclick="$('.recipe-nav-xs a').toggleClass('active');">INGREDIENTS</a></li>
                <li class="letter-spacing"><a href="#directions" onclick="$('.recipe-nav-xs a').toggleClass('active');">DIRECTIONS</a></li>
            </ul>
    	</div>
    
    </header>  
        	
        	
        
        
    <div id="background">
        <?php $recipeImage = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'tablet' ); ?>
    	<div class="background-normal" style="background: url(<?php echo $recipeImage[0]; ?>) no-repeat;"></div>
    </div>           
    
    
    
    <div id="content" class="">
    
        <div id="introduction" class="white sticky">
            <div class="container">
    	        <div class="row">
    		        <div class="col-xs-12 col-sm-10 col-sm-offset-1">
    			        <div class="recipe-introduction">
    				        <h1 class="title serif-alt text-uppercase"><?php the_title(); ?></h1>
    				        <div class="serves sans-serif uppercase tracked">
                			    <div class="serving-slug sans-serif letter-spacing">
            			            <b class="text-uppercase"><?php the_field('serving_slug') ?>: </b>
                			        <span class="light" itemprop="yield"><?php the_field('serves') ?></span>
                			    </div> 
    				         </div>
    				        <hr class="white" />
    			        </div>
    			        <div class="recipe-introduction-more sans-serif">
			        	    <div class="deck"><?php the_field('deck') ?></div>
                            <h6 class="letter-spacing photo-credit text-center">
            	                <?php echo apply_filters('the_content', get_post(get_post_thumbnail_id())->post_excerpt); ?>
            	                <br />
            	                <?php echo get_post(get_post_thumbnail_id())->post_content; ?>
            	            </h6>
    			        </div>
    		        </div>
    	        </div>
            </div>
        </div>
        
        
        
        
        <div id="recipe">
          <div class="container">
          
	        <div class="row">
		        <div class="col-xs-12 col-sm-10 col-sm-offset-1">
			        <div class="recipe-introduction">
				        <h2 class="title serif-alt text-uppercase"><?php the_title(); ?></h2>
				        <div class="serves sans-serif uppercase tracked">
            			    <div class="serving-slug sans-serif letter-spacing">
            			        <b class="text-uppercase"><?php the_field('serving_slug') ?>: </b>
            			        <span class="light" itemprop="yield"><?php the_field('serves') ?></span>
            			    </div> 
				         </div>
				         <hr />
			        </div>
		        </div>
	        </div>          
            
            <div class="row">
    	        <div class="recipe-steps col-xs-12 col-sm-10 col-sm-offset-1">
    	        
    	            <a name="ingredients"></a>
    	            
    	            
    				<div class="row">
    				
        			    <!-- RECIPE INGREDIENTS -->
                	    <div class="recipe-ingredients col-sm-5 col-md-4">
        				<?php if( have_rows('ingredient_group') ): ?>
        					<?php while( have_rows('ingredient_group') ): the_row(); ?>
        					
        						<?php if( get_sub_field('ingredient_group_name') ) : ?>
        						<h6 class="text-uppercase letter-spacing"><b><?php the_sub_field('ingredient_group_name'); ?></b></h6>
        						<?php endif; ?>
        					
        						<?php if( have_rows('ingredients') ): ?>
        						<ul class="ingredients sans-serif">
        							
        							
        							<?php while( have_rows('ingredients') ): the_row(); ?>	
        	                        <li class="ingredient"> 
        	                            <span itemprop="ingredient" itemscope="itemscope" itemtype="http://data-vocabulary.org/RecipeIngredient">                           
        	                                <?php if(!get_sub_field('ingredient_options') == 'hide_quantity') : ?>
        		                                <span itemprop="amount">
        		                                    <?php $from = array('1/4','1/2','3/4','1/3','2/3','1/5','2/5','3/5','4/5','1/6','5/6','1/8','3/8','5/8','7/8');?>
        		                                    <?php $to =   array('&#xBC;','&#xBD;','&#xBE;','&#x2153;','&#x2154;','&#x2155;','&#x2156;','&#x2157;','&#x2158;','&#x2159;','&#x215A;','&#x215B;','&#x215C;','&#x215D;','&#x215E;');?>
        		                                    <span class="amount"><?php echo str_replace( $from, $to, get_sub_field('quantity')); ?></span>
        		                                    <?php echo str_replace('single', '', get_sub_field('unit')); ?>
        		                                </span>
        	                                <?php endif; ?>
        	                                
        	                                <span itemprop="name">
        	                                	<?php if(get_sub_field('custom_name')) : ?>
        	                                		<?php the_sub_field('custom_name'); ?>
        	                                	<?php else: ?>
        	                                		<?php $ingredient = get_sub_field('ingredient'); ?>
        											<?php echo $ingredient->post_title; ?>
        											
        											<?php if(get_sub_field('prep_instructions')) : ?>
        												<?php the_sub_field('custom_name'); ?>
        											<?php endif; ?>
        										<?php endif; ?>
        	                                </span>
        	                            </span>
        	                        </li>							
        							<?php endwhile; ?>
        							
        							
        						</ul>
        						<br />
        						<?php endif; ?> 		
        			
        			
        					<?php endwhile; ?>
        				<?php endif; ?> 	    
        			    </div>
        			    <!-- END RECIPE INGREDIENTS -->
						
						
    					<a name="directions"></a>		
    											
        			    <!-- RECIPE INSTRUCTIONS -->
        			    <div class="recipe-instructions col-sm-7 col-md-8">			    
        			    
        					<?php if( have_rows('steps') ): ?>
        						<ul class="instructions">
        						<?php $i = 1; ?>
        						<?php while( have_rows('steps') ): the_row(); ?>	
        								    
        							<li class="instruction">
        							<?php if(get_sub_field('step')) : ?>
        	                    		<span class="step"><?php echo $i; ?></span>
        								<span itemprop="instruction" class="serif"><?php the_sub_field('step'); ?></span>						
        							<?php endif; ?>		
        							</li>
        						<?php $i++; ?>
        						<?php endwhile; ?>
        						</ul>
        					<?php endif; ?> 			    
        			    
        			    </div>
        			    <!-- END RECIPE INSTRUCTIONS -->
    			        
    			        
    				</div>
    	        </div>
            </div>
        </div>

       </div>
    </div>
    
    
    <script>
        var recipeJSON = <?php echo json_encode($recipe); ?>;
    </script>        
    
    
    
    <script src="<?php echo $filePath; ?>js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo $filePath; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo $filePath; ?>js/angular.min.js"></script>
    <script src="<?php echo $filePath; ?>js/sticky-kit.min.js"></script>
    <script src="<?php echo $filePath; ?>js/main.js"></script>
       
       
</body>
    
    
</html>

<?php endwhile; endif; ?>
