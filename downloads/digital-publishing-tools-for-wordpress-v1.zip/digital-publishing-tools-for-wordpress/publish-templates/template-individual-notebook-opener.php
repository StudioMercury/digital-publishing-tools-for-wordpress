<?php
/*
Template Name: Adobe Publish - Notebook Opener
*/
?>
<?php 

    // Make sure a recipe ID is set - then query that post
    if( isset($_GET["notebookpost"]) ) { 
        $recipeID = htmlspecialchars($_GET["notebookpost"]); 
        query_posts( array ( 'p' => $recipeID, 'post_type' => 'notebook' ) );
    }

    // Is this for a Folio or for preview
    if( isset($_GET["bundle"]) ) {
        $filePath = '../HTMLResources/';
        $urlPath = 'navto://';
    } else {
        $filePath = get_bloginfo('template_directory') . '/dps-templates/HTMLResources/';
        $urlPath = site_url() . '/publish-templates/template-notebook/?notebook=';
    }

?>

<?php if ( have_posts() ) : while (have_posts()) : the_post(); ?>
    
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" ng-app> <!--<![endif]-->
<head>        
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="description" content="<?php the_excerpt(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    
    <title>Gather Journal - <?php the_title(); ?></title>        

    <link rel="stylesheet" href="<?php echo $filePath; ?>css/fonts.css">    
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/gather-journal-font.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/royalslider.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/theme.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/template-notebook.css">

</head>


<body id="single-notebook-opener" ng-app="">

    <?php $headerImage = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' ); ?>
    <div class="header flex-bottom" style="background: url(<?php echo $headerImage['0']; ?>) no-repeat center center; background-size: cover;">         
        <div class="opener-text text-center <?php the_field('text_color', get_post_thumbnail_id($post->ID)); ?>">
            <?php $terms = get_the_terms( $post->ID , 'categories' );?>
            <h5 class="text-uppercase tracking">
                <b><span class="underline"><?php if($terms) { foreach ( $terms as $term ) { echo $term->name; } } ?></span></b>
            </h5>
            <h1 class="serif-alt text-uppercase"><?php the_title(); ?></h1>
            <h6 class="text-uppercase tracking"><?php the_date(); ?></h6>
            <br />
            <h1><i class="fa fa-angle-down"></i></h1>
        </div>
    </div>
    
    
    <div class="article-wrapper" style="background: <?php the_field('background_color'); ?>; color: <?php the_field('text_color'); ?>;">
        <div class="container">
                
            <article class="col-sm-10 col-sm-offset-1 serif">
                <?php the_content(); ?>
            </article>
            
        </div>
    </div>
    
    <script src="<?php echo $filePath; ?>js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo $filePath; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo $filePath; ?>js/angular.min.js"></script>
    <script src="<?php echo $filePath; ?>js/sticky-kit.min.js"></script>
    <script src="<?php echo $filePath; ?>js/jquery.royalslider.min.js"></script>
    <script src="<?php echo $filePath; ?>js/main.js"></script>
       
       
</body>
    
    
</html>

<?php endwhile; endif; ?>
