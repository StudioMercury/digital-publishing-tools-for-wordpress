<?php
/**
 *
 * Package: Folio Authoring for WordPress
 * Class : Settings
 * Description: This class contains settings specific parameters and functions.
 */
 
namespace DPSFolioAuthor;

if(!class_exists('DPSFolioAuthor\Settings')) { 

	class Settings {
               		
	    public $company = "";
	    public $key = ""; // v1 called key
	    public $secret = ""; // v1 called secret
	    public $device_token = "";
	    public $device_id = "";
	    public $refresh_token = "";
		public $access_token = '';
	    
	    public $authentication_endpoint = DPS_API_AUTHENTICATION_END;
	    public $authorization_endpoint = DPS_API_AUTHORIZATION_END;
	    public $ingestion_endpoint = DPS_API_INGESTION_END;
	    public $producer_endpoint = DPS_API_PRODUCER_END;
	    public $product_endpoint = DPS_API_PRODUCT_END;
	    public $portal_url = DPS_PORTAL;
	    
	    // Classic Settings
	    public $tooltips = true; // should tooltips appear
		public $auto_preview_toc = true; // used to be auto-preview-toc
		public $preset_template = ""; // preset template for articles
		public $htmlresources = ""; // default HTML resources to upload
		public $login = "";
		public $password = "";
		
		// plugin 2.0 Settings
		public $appMode = "app"; // `app` or `normal`
		public $apiVersion = 2.0;	
		public $publications = array();	
		public $permissions = array();
		
		public $devices = array();
		public $templates = array();
		
		// DEFAULTS
		public $defaultTemplate = "";
		public $defaultPublication = "";
		
        public function __construct(){
	        $settings = $this->get_settings();
	        foreach ($settings as $key => $val) {
		    	$this->$key = $val;
		    }
		    $this->update_templates();
		    $this->update_endpoints();
        }
        
        public function update_endpoints(){
	        $this->authentication_endpoint = DPS_API_AUTHENTICATION_END;
			$this->authorization_endpoint = DPS_API_AUTHORIZATION_END;
			$this->ingestion_endpoint = DPS_API_INGESTION_END;
			$this->producer_endpoint = DPS_API_PRODUCER_END;
			$this->product_endpoint = DPS_API_PRODUCT_END;
			$this->portal_url = DPS_PORTAL;
        }
        
        public function update(){
	        $this->refresh();
	        $this->update_templates();
	        $this->update_from_adobe();
		    $this->update_endpoints();
        }
        
        public function update_templates(){
	        $Templates = new Templates();
		    $this->templates = $Templates->get_templates();
        }
        
        public function update_from_adobe(){
	        $Adobe = new Adobe();
		    $this->publications = $Adobe->get_user_permissions();
		    $this->refresh();
        }	

		public function get_settings(){
			$CMS = new CMS();
			return $CMS->get_settings();
		}
		
		public function save(){
			$CMS = new CMS();
			$CMS->save_settings(get_object_vars($this));
		}
		
		public function refresh(){
			$data = $this->get_settings();
			$this->populate_object( $data );
		}
		
		public function populate_object($data = array()){
			$availableKeys = get_object_vars($this);
			foreach ($data as $key => $val) {
		    	if(array_key_exists($key, $availableKeys)){
			    	$this->$key = $val;
			    }
		    }
		}

    } // END class Settings
}
