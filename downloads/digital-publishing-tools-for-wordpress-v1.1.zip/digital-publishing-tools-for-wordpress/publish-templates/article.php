<h1><?php echo the_title(); ?></h1>
<article>
	<? echo $post->post_content; ?>
</article>