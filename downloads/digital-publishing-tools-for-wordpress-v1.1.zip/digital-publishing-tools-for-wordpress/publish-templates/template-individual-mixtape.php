<?php
/*
Template Name: Adobe Publish - Mixtape
*/
?>
<?php 

    // Make sure a recipe ID is set - then query that post
    if( isset($_GET["mixtape"]) ) { 
        $recipeID = htmlspecialchars($_GET["mixtape"]); 
        query_posts( array ( 'p' => $recipeID, 'post_type' => 'mixtapes' ) );
    }

    // Is this for a Folio or for preview
    if( isset($_GET["bundle"]) ) {
        $filePath = '../HTMLResources/';
        $urlPath = 'navto://';
    } else {
        $filePath = get_bloginfo('template_directory') . '/dps-templates/HTMLResources/';
        $urlPath = site_url() . '/publish-templates/template-notebook/?notebook=';
    }

?>

<?php if ( have_posts() ) : while (have_posts()) : the_post(); ?>
    
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" ng-app> <!--<![endif]-->
<head>        
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="description" content="<?php the_excerpt(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    
    <title>Gather Journal - <?php the_title(); ?></title>        

    <link rel="stylesheet" href="<?php echo $filePath; ?>css/fonts.css">    
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/gather-journal-font.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/royalslider.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/theme.css">
    <link rel="stylesheet" href="<?php echo $filePath; ?>css/template-notebook.css">

</head>


<body class="single-mixtape" ng-app="">

    <br /><br /><br />
        
    <div class="container">
    
        <div class="visible-xs col-xs-12">
        	<?php if(has_post_thumbnail()) :?>
        		<?php the_post_thumbnail( 'medium', array( 'class' => 'img-responsive' ) ); ?>
        	<?php endif; ?>  
        	<br />	
		</div>    
    
		<div class="col-xs-12 col-sm-8 col-md-7">
            <br />
            <h4 class="text-uppercase letter-spacing"><?php the_title(); ?></h4>
            <h4 class="sans-serif light"><?php the_content(); ?></h4>	
            <br />
            <a href="https://open.spotify.com/user/gatherjournal/playlist/<?php the_field('spotify_playlist_id'); ?>" class="btn btn-default text-uppercase">
	            <i class="fa fa-headphones"></i> Listen on Spotify
	        </a>	
            
            <br /><br />
            
		</div>
        
        <div class="col-xs-6 col-xs-offset-3 col-sm-offset-0 col-sm-4 col-md-4 col-md-offset-1 hidden-xs">
        	<?php if(has_post_thumbnail()) :?>
        		<?php the_post_thumbnail( 'medium', array( 'class' => 'img-responsive' ) ); ?>
        	<?php endif; ?>    			
		</div>	
			
        <div class="col-xs-12 ">
			<br />
            <hr />
            <br />
        </div>
            
        <div class="col-xs-12 ">
        
            <?php if( have_rows('tracks') ): ?>
            
			    <h5 class="">
				    <span class="text-uppercase letter-spacing">Preview Tracks</span>
				    <small><i>provided by iTunes</i></small>
				</h5>			
				<br />
				
				<div class="mixtape-tracks">
					<?php while( have_rows('tracks') ): the_row(); ?>
					<div class="col-xs-12 mixtape-track">
					
						<?php if(get_sub_field('itunes_preview_url')) : ?>
						<div class="play-button pull-left">
						    <audio src="<?php the_sub_field('itunes_preview_url'); ?>" preload="auto" />
							<i class="fa fa-play"></i>
						</div>
						<?php endif; ?>
						<h5 class="letter-spacing mixtape-track-name">
						    <b><?php the_sub_field('song_title'); ?></b> <?php the_sub_field('song_artist'); ?>
    						<?php if(get_sub_field('itunes_purchase_url')) : ?>
    						    <a href="<?php if(the_sub_field('itunes_purchase_url')); ?>" class="itunes-purchase-link">buy on iTunes</a>
    						<?php endif; ?>
                        </h5>
					</div>   
					<?php endwhile; ?>	
				</div>
				
			<?php endif; ?>
			
				
		</div>
    </div>
        

    
    <script src="<?php echo $filePath; ?>js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo $filePath; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo $filePath; ?>js/angular.min.js"></script>
    <script src="<?php echo $filePath; ?>js/sticky-kit.min.js"></script>
    <script src="<?php echo $filePath; ?>js/jquery.royalslider.min.js"></script>
    <script src="<?php echo $filePath; ?>js/audiojs/audio.min.js"></script>
    <script src="<?php echo $filePath; ?>js/main.js"></script>
       
       
</body>
    
    
</html>

<?php endwhile; endif; ?>
