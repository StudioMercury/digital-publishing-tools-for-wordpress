$(document).ready(function () {
	
    $(".slideshow").each(function(){
        $(this).royalSlider({
            autoScaleSlider:    true,
            loop:               true,
            autoPlay: {
        		enabled: true,
        		delay: 6000
        	}
        });    
	});  
	
	// CODE FOR SINGLE RECIPE
	if ($('#single-recipe').length > 0) { 
	    
	    $('#introduction').css({'margin-top':( ( $(window).height()) - ( $('.recipe-introduction').outerHeight() ) ) + 'px' } );
        $('#recipe').css({'min-height': ( $(window).height() ) + 'px' } );
        
        $(window).load(function(){
            var position = $('#recipe').position();
            $('#recipe-nav-xs').affix({
                offset: { top: position.top }
            });
        });   

    	// FADE IMAGE
        function getViewportHeight() {
            var height = window.innerHeight; // Safari, Opera
            var mode = document.compatMode;

            if ( (mode || !$.support.boxModel) ) { // IE, Gecko
                height = (mode == 'CSS1Compat') ?
                document.documentElement.clientHeight : // Standards
                document.body.clientHeight; // Quirks
            }
            
            return height;
        }
    
        $(window).scroll(function () {
            var vpH = getViewportHeight(),
                scrolltop = ($('body')[0].scrollTop ?
                    $('body')[0].scrollTop :
                    $('body')[0].scrollTop),
                elems = [];
            
                if( scrolltop < 0 ){
                    $(".background-normal").css({ "opacity" : 1 });
                    //console.log(1);
                }else if( scrolltop >= (vpH/2) ){
                    $(".background-normal").css({ "opacity" : 0 });
                    //console.log(0);
                }else if( scrolltop < (vpH/2) ){
                    value = 1 - scrolltop / (vpH/2);
                    $(".background-normal").css({ "opacity" : value });
                   // console.log(value);
                }
        });
        
        // kick the event to pick up any elements already in view.
        // note however, this only works if the plugin is included after the elements are bound to 'inview'
        $(function () {
            $(window).scroll();
        });	

	}
	

	// CODE FOR NOTEBOOK OPENER
	if ($('#single-notebook-opener').length > 0) { 	
        $('.header').css({'min-height':( $(window).height()) + 'px' } );
    }
	
	

		
});




$(window).resize(function() {
    
    // CODE FOR RECIPES
    if ($('#recipe').length > 0) { 
        $('#introduction').css({'margin-top':( ( $(window).height()) - ( $('.recipe-introduction').outerHeight() ) ) + 'px' } );
    }
    
    
	// CODE FOR NOTEBOOK OPENER
	if ($('#single-notebook-opener').length > 0) { 	
        $('.header').css({'min-height':( $(window).height()) + 'px' } );
    }    
    
    
});


$(window).load(function(){

    audiojs.events.ready(function() {
        var as = audiojs.createAll();
    });	

});





